# AI Risk Semantic Space — Scientific Reports submission package

Manuscript: **"Semantic network structure of an AI risk taxonomy reveals
loss-of-control concepts as connector hubs"** (Youngsam Chun, 2026).
Rebuilt 2026-07-23 in the official Overleaf `wlscirep` template.
Revised 2026-07-24: degree/centrality analysis now uses a construction-free
similarity-threshold network (no union-kNN degree floor), per author direction.

## Contents

- `main.tex` — complete manuscript (single file, references via `thebibliography`)
- `wlscirep.cls`, `jabbrv.sty`, `jabbrv-ltwa-all.ldf`, `jabbrv-ltwa-en.ldf` — template files
- `figures/fig1_network_map.pdf` — Fig. 1, semantic proximity network map
- `figures/fig2_structure.pdf` — Fig. 2, structural statistics (4 panels)
- `analysis/embed_cards.py` — re-embeds all 1,660 cards with BGE-M3 (FlagEmbedding)
- `analysis/threshold_network.py` — builds the construction-free threshold graph,
  runs threshold sensitivity and Clauset-style tail tests (powerlaw package)
- `analysis/network_stats.py` — statistics of the released union-kNN network
- `analysis/make_figures_v2.py` — regenerates both figures

## Build

pdfLaTeX, two passes. On Overleaf: upload the zip as a project, compiler = pdfLaTeX.

## Data

All data are public, release v2.17.2:

- Network: https://deep1003.github.io/RAI-Risk-Taxonomy-2.0/public/data/releases/v2.17.2/semantic_proximity_network.json
- Cards/coordinates: https://deep1003.github.io/RAI-Risk-Taxonomy-2.0/public/data/releases/v2.17.2/risk_space.json
- Repository: https://github.com/deep1003/RAI-Risk-Taxonomy-2.0

Run the analysis scripts from `analysis/` with the network JSON path as the
first argument (default expects `../../data/semantic_proximity_network.json`).

## Verified key numbers

Released union-kNN network (v2.17.2, used for communities/layout only):
- Evidence chain: 3,906,767 → 82,971 → 1,726 → 1,711 → 1,660 active cards
- 1,660 nodes / 11,869 edges, single component; 50 EM communities
  (2–140, median 25), EM converged in 16 iterations (mean cosine 0.751)
- Multi-affiliation (≥2 families, threshold 0.03): 459 cards = 27.7%, max 8

Construction-free similarity-threshold network (θ=0.62, primary for
degree/centrality; embeddings reproduced with r=0.980, MAE 0.014):
- 90,848 edges; mean k 109.5, median 69, max 554; 5 isolates, GCC 1,655;
  clustering 0.432; assortativity +0.197; Gini degree 0.504
- Power law REJECTED: LR tests favour lognormal/exponential (all p<0.001)
- Rank stability: Spearman 0.89 (θ=0.62 vs 0.68), 0.94 vs threshold-free strength
- Top hub RAI4-0592 k=554 (rank 1 at θ=0.60–0.65); control-erosion theme:
  16 of top 30 cards; hub P 0.92–0.95, spanning 42–48 of 50 communities
- HOLD: 63.5% in top degree decile vs 44.1% elsewhere (overall 46.1%)
- RAI4-1616 (union-kNN rank 1) → rank 58 (top 3.5%) without the construction

## Remaining author actions before submission

1. Confirm author name spelling (Chun, per previous Sci Rep submission),
   affiliations, corresponding email (deep1003@snu.ac.kr), ORCID.
2. Replace the Zenodo placeholder in Data availability with the actual DOI.
3. Adjust the AI-tools declaration in Methods if desired.
4. Confirm Competing interests wording (KT employment declared).
5. Card severity/probability/impact fields are excluded by design — keep it so.

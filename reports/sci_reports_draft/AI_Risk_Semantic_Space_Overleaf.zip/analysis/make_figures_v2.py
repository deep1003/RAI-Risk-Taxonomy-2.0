#!/usr/bin/env python3
"""Manuscript figures, v2: degree analysis uses the construction-free
similarity-threshold network (theta=0.62) built from recomputed BGE-M3
embeddings; the released union-kNN network is used only for the Fig. 1
layout and EM communities."""
import json
import pickle
from collections import Counter

import matplotlib as mpl
import matplotlib.pyplot as plt
import matplotlib.lines as mlines
import networkx as nx
import numpy as np
from matplotlib.collections import LineCollection

mpl.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["Helvetica", "Arial", "DejaVu Sans"],
    "font.size": 7, "axes.labelsize": 7, "axes.titlesize": 8,
    "xtick.labelsize": 6, "ytick.labelsize": 6, "legend.fontsize": 6,
    "axes.linewidth": 0.6, "pdf.fonttype": 42,
})

net = json.load(open("../../data/semantic_proximity_network.json"))
nodes, edges = net["nodes"], net["edges"]
clusters = {c["id"]: c for c in net["clusters"]}
N = len(nodes)
id2idx = {n["id"]: i for i, n in enumerate(nodes)}
comm = {i: nodes[i]["cluster"] for i in range(N)}

emb = np.load("embeddings.npy")
ids = json.load(open("embedding_ids.json"))
id2e = {ids[i]: i for i in range(len(ids))}
E = emb[[id2e[n["id"]] for n in nodes]]
S = E @ E.T
np.fill_diagonal(S, 0.0)
THETA = 0.62
kfree = (S >= THETA).sum(1)          # construction-free degree
kknn = np.array([0] * N)
Gk = nx.Graph(); Gk.add_nodes_from(range(N))
for e in edges: Gk.add_edge(e[0], e[1])
kknn = np.array([Gk.degree(i) for i in range(N)])

HUBS = ["RAI4-0592", "RAI4-1482", "RAI4-1552", "RAI4-0894"]

BASE = ["#0072B2", "#E69F00", "#009E73", "#D55E00", "#CC79A7",
        "#56B4E9", "#F0E442", "#8C6BB1", "#A6761D", "#332288"]
sizes = Counter(comm.values())
major = [cid for cid, _ in sizes.most_common(10)]
cmap = {cid: BASE[j] for j, cid in enumerate(major)}
GRAY = "#C9CDD3"
BLUE, ORANGE, DARK, VERM = "#0072B2", "#E69F00", "#333333", "#D55E00"

# ================================================================= FIG 1
fig, ax = plt.subplots(figsize=(7.2, 6.4))
xs = np.array([n["x"] for n in nodes]); ys = np.array([n["y"] for n in nodes])
segs = [[(xs[a], ys[a]), (xs[b], ys[b])] for a, b, *r in ((e[0], e[1]) for e in edges)]
ax.add_collection(LineCollection(segs, colors="k", linewidths=0.08, alpha=0.10,
                                 zorder=1, rasterized=True))
node_sizes = 1.5 + 24.0 * (kfree / kfree.max()) ** 1.5
cols = [cmap.get(comm[i], GRAY) for i in range(N)]
ax.scatter(xs, ys, s=node_sizes, c=cols, linewidths=0.15, edgecolors="white",
           zorder=2, rasterized=True)
for hid in HUBS:
    i = id2idx[hid]
    ax.scatter(xs[i], ys[i], s=node_sizes[i] * 2.2, facecolors="none",
               edgecolors="#111111", linewidths=0.9, zorder=4)
annot = {
    "RAI4-0592": ("Collectively inefficient\nequilibria among AI agents\n(k = 554, rank 1)", (-95, -30)),
    "RAI4-1482": ("Automation bias\n(k = 527, rank 2)", (-108, -38)),
    "RAI4-1552": ("Overreliance on AI\nundermining user autonomy", (26, 24)),
    "RAI4-0894": ("Loss of human agency\nand autonomy", (30, -34)),
}
for hid, (txt, off) in annot.items():
    i = id2idx[hid]
    ax.annotate(txt, (xs[i], ys[i]), textcoords="offset points", xytext=off,
                fontsize=5.6, fontstyle="italic",
                arrowprops=dict(arrowstyle="-", lw=0.5, color="#333333",
                                shrinkA=0, shrinkB=2),
                bbox=dict(boxstyle="round,pad=0.22", fc="white", ec="#666666",
                          lw=0.4, alpha=0.92), zorder=6, ha="left")
for cid, _ in sizes.most_common(5):
    mem = [i for i in range(N) if comm[i] == cid]
    lab = clusters[cid]["label_en"]
    if lab == "Misinformation/Disinformation":
        lab = "Misinformation/\nDisinformation"
    ax.text(xs[mem].mean(), ys[mem].mean(), lab, fontsize=7.5,
            fontweight="bold", color="#222222", ha="center", va="center",
            zorder=5, bbox=dict(boxstyle="round,pad=0.25", fc="white",
                                ec="none", alpha=0.72))
handles = [mlines.Line2D([], [], marker="o", ls="none", markersize=4,
                         markerfacecolor=cmap[c], markeredgecolor="none",
                         label=f"{clusters[c]['label_en']} ({sizes[c]})")
           for c in major]
handles.append(mlines.Line2D([], [], marker="o", ls="none", markersize=4,
                             markerfacecolor=GRAY, markeredgecolor="none",
                             label="Other 40 communities"))
ax.legend(handles=handles, loc="upper left", frameon=False,
          handletextpad=0.1, borderaxespad=0.2, labelspacing=0.35)
ax.set_xlim(xs.min()-0.05, xs.max()+0.05); ax.set_ylim(ys.min()-0.05, ys.max()+0.05)
ax.set_aspect("equal"); ax.axis("off")
fig.tight_layout(pad=0.2)
fig.savefig("../figures/fig1_network_map.pdf", dpi=600, bbox_inches="tight")
fig.savefig("../figures/fig1_network_map.png", dpi=450, bbox_inches="tight")
plt.close(fig)
print("fig1 done")

# ================================================================= FIG 2
fig, axes = plt.subplots(2, 2, figsize=(7.2, 5.6))
(a, b), (c, d) = axes

# (a) CCDF of construction-free degree
kk = np.sort(kfree[kfree > 0])
ccdf = 1.0 - np.arange(len(kk)) / len(kk)
a.loglog(kk, ccdf, color=BLUE, lw=1.2)
i592 = id2idx["RAI4-0592"]
a.scatter([kfree[i592]], [1.0/len(kk)], s=14, facecolors="none",
          edgecolors="#111111", linewidths=0.8, zorder=5)
a.annotate("RAI4-0592 (k = 554)", (kfree[i592], 1.2/len(kk)),
           xytext=(90, 3e-3), fontsize=5.6,
           arrowprops=dict(arrowstyle="-", lw=0.5, color=DARK))
a.axvline(np.median(kfree), color=ORANGE, lw=0.9, ls="--")
a.text(np.median(kfree)*1.1, 2e-3, "median = 69", fontsize=5.6,
       color="#8a5b00", rotation=90, va="bottom")
a.text(0.04, 0.13,
       "LR tests reject a power-law tail\n(vs lognormal, exponential:\nall $p<0.001$); Gini = 0.50",
       transform=a.transAxes, fontsize=5.8,
       bbox=dict(boxstyle="round,pad=0.3", fc="#F5F6F8", ec="#CCCCCC", lw=0.4))
a.set_xlabel("Degree k (similarity threshold graph, $\\theta=0.62$)")
a.set_ylabel("P(K $\\geq$ k)")
a.set_title("a", loc="left", fontweight="bold")

# (b) threshold sensitivity
ths = [0.55, 0.58, 0.60, 0.62, 0.65, 0.68, 0.70]
med_, max_, gin_ = [], [], []
def gini(x):
    x = np.sort(np.asarray(x, float)); n = len(x)
    return (2*np.sum(np.arange(1, n+1)*x)/(n*x.sum())) - (n+1)/n
for th in ths:
    kt = (S >= th).sum(1)
    med_.append(np.median(kt)); max_.append(kt.max()); gin_.append(gini(kt))
b.semilogy(ths, max_, "o-", color=VERM, lw=1, ms=3, label="max degree")
b.semilogy(ths, med_, "s-", color=BLUE, lw=1, ms=3, label="median degree")
b.axvline(THETA, color=DARK, lw=0.7, ls=":", label="_nolegend_")
b.text(THETA+0.002, 600, "$\\theta=0.62$\n(pipeline min.\nsimilarity)", fontsize=5.4)
b2 = b.twinx()
b2.plot(ths, gin_, "^-", color=ORANGE, lw=1, ms=3, label="Gini")
b2.set_ylabel("Gini coefficient", color="#8a5b00", fontsize=7)
b2.tick_params(axis="y", labelcolor="#8a5b00", labelsize=6)
b2.set_ylim(0.2, 0.65)
lines = [l for l in b.get_lines() + b2.get_lines() if not l.get_label().startswith("_")]
b.legend(lines, [l.get_label() for l in lines], frameon=False, loc="lower left")
b.set_xlabel("Similarity threshold $\\theta$")
b.set_ylabel("Degree")
b.set_title("b", loc="left", fontweight="bold")

# (c) HOLD share by degree decile
hold = np.array([bool(n.get("hold")) for n in nodes])
dec = np.clip((np.argsort(np.argsort(kfree)) / N * 10).astype(int), 0, 9)
shares = [100*hold[dec == q].mean() for q in range(10)]
c.bar(np.arange(1, 11), shares, color=[BLUE]*9 + [VERM], width=0.8)
c.axhline(100*hold.mean(), color=DARK, lw=0.8, ls="--")
c.text(0.7, 100*hold.mean()+1.2, f"overall {100*hold.mean():.1f}%", fontsize=5.6)
c.text(10, shares[-1]+1.2, f"{shares[-1]:.0f}%", fontsize=5.8, ha="center",
       color=VERM, fontweight="bold")
c.set_xlabel("Degree decile (1 = lowest, 10 = highest)")
c.set_ylabel("Cards under HOLD review (%)")
c.set_xticks(range(1, 11))
c.set_title("c", loc="left", fontweight="bold")

# (d) kNN degree vs construction-free degree
d.scatter(kfree, kknn, s=4, c="#9AA3AC", alpha=0.5, linewidths=0,
          rasterized=True)
for hid in HUBS + ["RAI4-1616"]:
    i = id2idx[hid]
    col = "#111111" if hid != "RAI4-1616" else VERM
    d.scatter(kfree[i], kknn[i], s=16, facecolors="none", edgecolors=col,
              linewidths=0.9, zorder=5)
d.annotate("RAI4-1616\n(kNN rank 1 $\\to$ rank 58)",
           (kfree[id2idx['RAI4-1616']], kknn[id2idx['RAI4-1616']]),
           xytext=(30, 36), fontsize=5.4, color=VERM,
           arrowprops=dict(arrowstyle="-", lw=0.5, color=VERM))
d.annotate("RAI4-0592",
           (kfree[i592], kknn[i592]), xytext=(430, 24), fontsize=5.4,
           arrowprops=dict(arrowstyle="-", lw=0.5, color=DARK))
d.axhline(10, color=DARK, lw=0.6, ls=":")
d.text(430, 10.6, "union-kNN floor", fontsize=5.4)
from scipy.stats import spearmanr
rho = spearmanr(kfree, kknn).statistic
d.text(0.03, 0.9, f"Spearman $\\rho$ = {rho:.2f}", transform=d.transAxes,
       fontsize=6)
d.set_xlabel("Construction-free degree ($\\theta=0.62$)")
d.set_ylabel("Released union-kNN degree")
d.set_title("d", loc="left", fontweight="bold")

for ax_ in (a, b, c, d):
    ax_.spines[["top", "right"]].set_visible(False)
b2.spines[["top"]].set_visible(False)

fig.tight_layout(pad=0.6)
fig.savefig("../figures/fig2_structure.pdf", dpi=600, bbox_inches="tight")
fig.savefig("../figures/fig2_structure.png", dpi=450, bbox_inches="tight")
plt.close(fig)
print("fig2 done")
print("spearman kNN vs free:", rho)

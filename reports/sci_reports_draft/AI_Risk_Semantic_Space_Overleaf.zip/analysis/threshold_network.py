#!/usr/bin/env python3
"""Build a construction-free semantic similarity network (no kNN, no degree
floor) from recomputed BGE-M3 embeddings, and run formal tail diagnostics.

Primary graph: edge iff cosine(i,j) >= theta. Sensitivity across thetas.
Validation: recomputed similarities are compared against the direct
similarities stored on the released union-kNN edges.
"""
import json
import sys
from collections import Counter

import networkx as nx
import numpy as np

theta_main = 0.62

emb = np.load("embeddings.npy")
ids = json.load(open("embedding_ids.json"))
net = json.load(open("../../data/semantic_proximity_network.json"))
nodes = net["nodes"]
clusters = {c["id"]: c for c in net["clusters"]}
id2i = {ids[i]: i for i in range(len(ids))}
# align: network node order may differ from risk_space order
order = [id2i[n["id"]] for n in nodes]
E = emb[order]  # embeddings in network-node order
N = len(nodes)

S = E @ E.T
np.fill_diagonal(S, 0.0)

# ---- validation against released direct similarities
rel = net["edges"]
released_sims = np.array([e[4] for e in rel])
mine = np.array([S[e[0], e[1]] for e in rel])
corr = np.corrcoef(released_sims, mine)[0, 1]
mae = np.abs(released_sims - mine).mean()
print(f"validation vs released direct sims: r={corr:.4f} MAE={mae:.4f}")

def build(theta):
    iu = np.triu_indices(N, 1)
    mask = S[iu] >= theta
    G = nx.Graph()
    G.add_nodes_from(range(N))
    src, dst = iu[0][mask], iu[1][mask]
    w = S[iu][mask]
    G.add_weighted_edges_from(zip(src.tolist(), dst.tolist(), w.tolist()))
    return G

def gini(x):
    x = np.sort(np.asarray(x, float)); n = len(x)
    if x.sum() == 0: return 0.0
    return (2*np.sum(np.arange(1, n+1)*x)/(n*x.sum())) - (n+1)/n

print("\n--- threshold sensitivity ---")
for th in [0.55, 0.58, 0.60, 0.62, 0.65, 0.68, 0.70]:
    G = build(th)
    k = np.array([d for _, d in G.degree()])
    iso = (k == 0).sum()
    comps = nx.number_connected_components(G)
    gcc = len(max(nx.connected_components(G), key=len))
    print(f"th={th:.2f} edges={G.number_of_edges():6d} mean_k={k.mean():6.2f} "
          f"med={np.median(k):5.1f} max={k.max():4d} iso={iso:4d} "
          f"comps={comps:4d} GCC={gcc:4d} gini={gini(k):.3f}")

print(f"\n=== main graph theta={theta_main} ===")
G = build(theta_main)
k = np.array([d for _, d in G.degree()])
s = np.array([d for _, d in G.degree(weight='weight')])
print(f"nodes={N} edges={G.number_of_edges()} mean_k={k.mean():.2f} "
      f"median={np.median(k):.0f} max={k.max()} isolates={(k==0).sum()}")
Gsub = G.subgraph(max(nx.connected_components(G), key=len))
print(f"GCC size={Gsub.number_of_nodes()} clustering={nx.average_clustering(G):.3f} "
      f"assortativity={nx.degree_assortativity_coefficient(G):+.3f}")
print(f"gini_k={gini(k):.3f} gini_s={gini(s):.3f}")
med = np.median(k)
print(f"nodes >=2x median: {(k>=2*med).sum()} ({100*(k>=2*med).mean():.1f}%)  "
      f">=4x: {(k>=4*med).sum()}")

# top hubs
comm = {i: nodes[i]["cluster"] for i in range(N)}
def participation(G):
    P = {}
    for v in G.nodes:
        kv = G.degree(v)
        if kv == 0: P[v] = 0.0; continue
        cnt = Counter(comm[u] for u in G.neighbors(v))
        P[v] = 1 - sum((c/kv)**2 for c in cnt.values())
    return P
P = participation(G)
pv = np.array([P[i] for i in range(N)])

print("\nTop-15 hubs (no-floor threshold graph):")
orderk = np.argsort(-k)
for v in orderk[:15]:
    n = nodes[v]
    ncomms = len(set(comm[u] for u in G.neighbors(v)))
    pct = 100*(pv < P[v]).mean()
    print(f"  {n['id']} | {n['label_en'][:52]:52s} | k={k[v]:3d} | "
          f"{clusters[n['cluster']]['label_en'][:22]:22s} | P={P[v]:.2f}({pct:.0f}) | "
          f"spans {ncomms} comms | hold={n.get('hold')}")

# HOLD enrichment
hold = np.array([bool(n.get("hold")) for n in nodes])
thr90 = np.percentile(k, 90)
print(f"\nHOLD overall {100*hold.mean():.1f}% | top-decile(k>={thr90:.0f}) "
      f"{100*hold[k>=thr90].mean():.1f}% vs rest {100*hold[k<thr90].mean():.1f}%")

# formal tail analysis
import powerlaw
kk = k[k > 0]
fit = powerlaw.Fit(kk, discrete=True, verbose=False)
print(f"\npowerlaw fit: alpha={fit.power_law.alpha:.2f} xmin={fit.power_law.xmin} "
      f"ntail={ (kk>=fit.power_law.xmin).sum() }")
for alt in ["lognormal", "exponential", "truncated_power_law", "stretched_exponential"]:
    R, p = fit.distribution_compare("power_law", alt, normalized_ratio=True)
    print(f"  power_law vs {alt}: R={R:+.2f} p={p:.3f}")
R, p = fit.distribution_compare("lognormal", "exponential", normalized_ratio=True)
print(f"  lognormal vs exponential: R={R:+.2f} p={p:.3f}")

np.save("degrees_threshold.npy", k)
np.save("strength_threshold.npy", s)
json.dump({ids[order.index(i)] if False else nodes[i]["id"]: int(k[i]) for i in range(N)},
          open("degree_threshold.json", "w"))
import pickle
pickle.dump(G, open("G_threshold.pkl", "wb"))
print("\nsaved graph + degrees")

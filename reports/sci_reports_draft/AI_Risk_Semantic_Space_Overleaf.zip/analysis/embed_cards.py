#!/usr/bin/env python3
"""Embed all 1,660 active L4 cards with BGE-M3 (dense), matching the released
pipeline's card-text construction: EN label + EN definition + KO label + KO
definition. Saves L2-normalized embeddings to embeddings.npy."""
import json
import numpy as np
from FlagEmbedding import BGEM3FlagModel

rs = json.load(open("../../data/risk_space.json"))
pts = rs["points"]
texts = []
ids = []
for p in pts:
    parts = [p.get("label_en") or "", p.get("definition_en") or "",
             p.get("label_ko") or "", p.get("definition_ko") or ""]
    texts.append("\n".join(s for s in parts if s))
    ids.append(p["id"])

model = BGEM3FlagModel("BAAI/bge-m3", use_fp16=False, device="cpu")
out = model.encode(texts, batch_size=16, max_length=512,
                   return_dense=True, return_sparse=False,
                   return_colbert_vecs=False)
emb = np.asarray(out["dense_vecs"], dtype=np.float32)
emb /= np.linalg.norm(emb, axis=1, keepdims=True)
np.save("embeddings.npy", emb)
json.dump(ids, open("embedding_ids.json", "w"))
print("saved", emb.shape)

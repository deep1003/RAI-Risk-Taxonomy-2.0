#!/usr/bin/env python3
"""Recompute all network statistics for the AI Risk Semantic Space manuscript.

Data: semantic_proximity_network.json (release v2.17.2)
Source: https://github.com/deep1003/RAI-Risk-Taxonomy-2.0
Note: L4 severity/probability/impact fields are intentionally NOT used.
"""
import json
import sys
from collections import Counter

import networkx as nx
import numpy as np

DATA = sys.argv[1] if len(sys.argv) > 1 else "../../data/semantic_proximity_network.json"

net = json.load(open(DATA))
nodes = net["nodes"]
edges = net["edges"]
clusters = {c["id"]: c for c in net["clusters"]}

G = nx.Graph()
for i, n in enumerate(nodes):
    G.add_node(i, **n)
# edge format: [src_idx, dst_idx, weight, distance, direct_sim, projected?]
for e in edges:
    G.add_edge(e[0], e[1], weight=e[2])

N, M = G.number_of_nodes(), G.number_of_edges()
deg = dict(G.degree())
strength = dict(G.degree(weight="weight"))
kvals = np.array(sorted(deg.values()))

print(f"nodes={N} edges={M}")
print(f"connected_components={nx.number_connected_components(G)}")
print(f"density={nx.density(G):.4f}")
print(f"mean_k={kvals.mean():.2f} median_k={np.median(kvals):.0f} min_k={kvals.min()} max_k={kvals.max()}")
print(f"clustering={nx.average_clustering(G):.3f}")
print(f"assortativity={nx.degree_assortativity_coefficient(G):+.3f}")

# Gini
def gini(x):
    x = np.sort(np.asarray(x, dtype=float))
    n = len(x)
    return (2 * np.sum((np.arange(1, n + 1)) * x) / (n * x.sum())) - (n + 1) / n

print(f"gini_degree={gini(list(deg.values())):.3f} gini_strength={gini(list(strength.values())):.3f}")
med = np.median(kvals)
above2med = sum(1 for k in deg.values() if k > 2 * med)
print(f"nodes_k_gt_2median={above2med} ({100*above2med/N:.1f}%)")

# communities
comm = {i: nodes[i]["cluster"] for i in G.nodes}
sizes = Counter(comm.values())
sz = np.array(sorted(sizes.values()))
print(f"communities={len(sizes)} size_min={sz.min()} size_max={sz.max()} size_median={np.median(sz):.0f}")
top5 = sizes.most_common(5)
for cid, s in top5:
    print(f"  comm {cid} '{clusters[cid]['label_en']}' size={s}")

# multi-affiliation (threshold 0.03)
multi = [n for n in nodes if n.get("l3_affiliation_count", 1) >= 2]
maxaff = max(n.get("l3_affiliation_count", 1) for n in nodes)
print(f"multi_affiliation>=2: {len(multi)} ({100*len(multi)/N:.1f}%) max={maxaff}")

# participation coefficient (Guimera & Amaral 2005)
def participation(G, comm):
    P = {}
    for v in G.nodes:
        k = deg[v]
        if k == 0:
            P[v] = 0.0
            continue
        cnt = Counter(comm[u] for u in G.neighbors(v))
        P[v] = 1.0 - sum((c / k) ** 2 for c in cnt.values())
    return P

P = participation(G, comm)
pvals = np.array(list(P.values()))
print(f"participation_median={np.median(pvals):.3f}")

# HOLD stats
hold = [i for i in G.nodes if nodes[i].get("hold")]
print(f"HOLD={len(hold)} ({100*len(hold)/N:.1f}%)")
k_thresh = np.percentile(kvals, 90)
top10pct = [i for i in G.nodes if deg[i] >= k_thresh]
rest = [i for i in G.nodes if deg[i] < k_thresh]
h_top = 100 * sum(1 for i in top10pct if nodes[i].get("hold")) / len(top10pct)
h_rest = 100 * sum(1 for i in rest if nodes[i].get("hold")) / len(rest)
print(f"degree>=p90 threshold k={k_thresh:.0f}: n={len(top10pct)} HOLD {h_top:.1f}% vs rest {h_rest:.1f}%")

# top-10 hubs
print("\nTop-10 hubs (id / label / k / s / community / #affil / P / P-percentile):")
order = sorted(G.nodes, key=lambda v: (-deg[v], -strength[v]))
for v in order[:10]:
    n = nodes[v]
    pct = 100 * (pvals < P[v]).mean()
    print(f"  {n['id']} | {n['label_en'][:55]} | k={deg[v]} | s={strength[v]:.2f} | "
          f"{clusters[n['cluster']]['label_en']} | affil={n.get('l3_affiliation_count')} | "
          f"P={P[v]:.2f} | pct={pct:.0f}")

# how many nodes chose each top hub as neighbor beyond the floor:
# every node initiates k=10 projected-kNN choices; degree above floor ~ times chosen
print("\nDegree floor analysis: min_k =", kvals.min())
kmed = np.median(kvals)
n1616 = [i for i in G.nodes if nodes[i]["id"] == "RAI4-1616"][0]
print(f"RAI4-1616 k={deg[n1616]}, ~chosen_by={deg[n1616]-10} (median excess {kmed-10:.0f})")

# neighbor community spread of top-4 hubs
for hub_id in ["RAI4-1616", "RAI4-0592", "RAI4-0894", "RAI4-1552"]:
    v = [i for i in G.nodes if nodes[i]["id"] == hub_id][0]
    ncomms = set(comm[u] for u in G.neighbors(v))
    print(f"{hub_id}: neighbors span {len(ncomms)} communities")
